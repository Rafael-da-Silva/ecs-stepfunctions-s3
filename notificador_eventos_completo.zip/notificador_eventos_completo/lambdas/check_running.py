import boto3
import os
import json
import logging

def lambda_handler(event, context):
    client = boto3.client('stepfunctions')
    sfn_arn = os.environ['STEP_FUNCTION_ARN']
    
    response = client.list_executions(
        stateMachineArn=sfn_arn,
        statusFilter='RUNNING'
    )
    
    if len(response['executions']) == 0:
        client.start_execution(
            stateMachineArn=sfn_arn,
            input=json.dumps({})
        )
        print("iniciou a execução!")
        logging.info("iniciou a execução!")
        
    
    return {
        'statusCode': 200,
        'body': json.dumps('Triggered Step Function if not already running')
    }
