import boto3
import os
import time
import logging

def lambda_handler(event, context):
    ssm_client = boto3.client('ssm')
    
    current_timestamp = int(time.time() * 1000) - 1000 # removendo 1 segundo

    
    last_execution_time_param = ssm_client.get_parameter(
        Name=os.environ['LAST_EXECUTION_TIME_PARAM']
    )
    
    last_execution_time = int(last_execution_time_param['Parameter']['Value'])
    
    lambda_count_param = ssm_client.get_parameter(
        Name=os.environ['LAMBDA_COUNT_PARAM']
    )
    
    lambda_count = int(lambda_count_param['Parameter']['Value'])
    
    interval_duration = int((current_timestamp - last_execution_time) / lambda_count)
    
    intervals = []
    for i in range(lambda_count):
        if i == 0:
            start_time = int(last_execution_time)
        else:
            start_time = int(intervals[-1]['end_time'])
        
        end_time = int(start_time) + int(interval_duration)
        
        print(f"Início: {start_time} e fim: {end_time}")
        logging.info(f"Início: {start_time} e fim: {end_time}")
        
        intervals.append({
            "start_time": str(start_time),
            "end_time": str(end_time)
        })
    
    # Atualizar o último intervalo de tempo final no Parameter Store
    last_interval_end_time = intervals[-1]['end_time']
    ssm_client.put_parameter(
        Name=os.environ['LAST_INTERVAL_END_TIME_PARAM'],
        Value=str(last_interval_end_time),
        Type='String',
        Overwrite=True
    )
    
    return {
        'intervals': intervals
    }